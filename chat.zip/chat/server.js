const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
}); 