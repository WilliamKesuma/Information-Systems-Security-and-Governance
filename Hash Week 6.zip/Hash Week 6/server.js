// Kita mulai dengan meng-import modul yang dibutuhkan: http untuk membuat server dan socket.io untuk komunikasi WebSocket
const http = require("http");
const { disconnect, connected } = require("process");


const socketIo = require ("socket.io");
const { Socket } = require("socket.io-client");

// Di sini, kita membuat server HTTP dan menghubungkannya dengan socket.io agar bisa mendengarkan koneksi WebSocket yang masuk
const server = http.createServer();
const io = socketIo(server);

// Saat klien terhubung, event connection akan terpicu, dan kita mencatat ID klien. Setiap koneksi klien direpresentasikan oleh objek socket    
io.on ("connection", (socket) => {
    console.log(`Client ${socket.id} connected`);

    socket.on("disconnect", () => {
        console.log(`Client ${socket.id} disconnected`);
    });

    // Server mendengarkan event message dari klien. Saat klien mengirim pesan, pesan tersebut akan tiba di sini dengan data username, pesan, dan hash.
    socket.on("message", (data) => {
        let{ username, message } = data;
        console.log(`Receiveing message from ${username}: ${message}`);

        data.message += " (tampered)";

        // pesan diterima, server mengirimkannya ke semua klien yang terhubung. server berbahaya mungkin mencoba memodifikasi pesan di sini. 
        //klien kita akan dapat mendeteksi setiap modifikasi karena verifikasi hash, seperti yang akan kita lihat nanti.
        io.emit("message", data);
    });
});

//port 3000 agar klien bisa terhubung.
const port = 3000;
server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

