// import socket.io-client untuk terhubung ke server, readline untuk menangkap input pengguna, dan crypto untuk hashing
const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "> "
});

let username = "";

// generateHash ini mengambil pesan dan mengembalikan hash SHA-256-nya. memastikan bahwa pesan tidak diubah.
function generateHash(message) {
    return crypto.createHash("sha256").update(message).digest("hex");
}

socket.on("connect", () => {
    console.log("Connected to the server");

    // Klien meminta pengguna untuk memasukkan username 
    // dan username ini digunakan untuk mengidentifikasi mereka di dalam chat.
    rl.question("Enter your username: ", (input) => {
        username = input;
        console.log(`Welcome, ${username} to the chat`);
        rl.prompt();

        rl.on("line", (message) => {
            if (message.trim()) {
                // Generate hash of the message
                const hash = generateHash(message);

                // Send message with hash to the server
                socket.emit("message", { username, message, hash });
            }
            rl.prompt();
        });
    });
});

socket.on("message", (data) => {
    const { username: senderUsername, message: senderMessage, hash: senderHash } = data;
    
    // Verify the integrity of the message
    const calculatedHash = generateHash(senderMessage);
    if (calculatedHash === senderHash) {
        console.log(`${senderUsername}: ${senderMessage}`);
    } else {
        console.log(`Warning: Message from ${senderUsername} may have been tampered with!`);
    }
    
    rl.prompt();
});

socket.on("disconnect", () => {
    console.log("Server disconnected, Exiting...");
    rl.close();
    process.exit(0);
});

rl.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
});
